package maskShop;

import maskShop.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bouncycastle.util.Integers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{

    @Autowired
    InventoryRepository inventoryRepository;

    @Autowired
    ProductRepository productRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void onStringEventListener(@Payload String eventString){

    }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrdered_Change(@Payload Ordered ordered){

        if(ordered.isMe()){

            System.out.println("##### listener Ship : " + ordered.toJson());
            System.out.println ("this is inventory");

            Inventory inventory = new Inventory();
            inventory.setProductId(ordered.getProductId());

            //inventory.setInvQty(inventory.getInvQty()-ordered.getQty());
            inventoryRepository.save(inventory);

            }
        }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOrderCanceled_Change(@Payload OrderCanceled orderCanceled){

        if(orderCanceled.isMe()){
            System.out.println("##### listener Change : " + orderCanceled.toJson());

            Inventory inventory = new Inventory();
            inventory.setProductId(orderCanceled.getProductId());
            //inventory.setInvQty(inventory.getInvQty()-orderCanceled.getQty());
            inventoryRepository.save(inventory);

        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverRegisterd_Add(@Payload Registerd registerd){

        if(registerd.isMe()){
            System.out.println("##### listener Add : " + registerd.toJson());

            Product product = new Product();
            product.setProductId(registerd.getProductId());
            product.setProductName(registerd.getProductName());
            productRepository.save(product);

            Inventory inventory = new Inventory();
            inventory.setProductId(registerd.getProductId());
            int var = 10;
            inventory.setInvQty(Integers.valueOf(var));
            inventoryRepository.save(inventory);


        }
    }


}
