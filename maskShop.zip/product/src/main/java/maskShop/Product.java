package maskShop;

import javax.persistence.*;
import org.springframework.beans.BeanUtils;
import java.util.List;

@Entity
@Table(name="Product_table")
public class Product {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;
    private Long productId;
    private String productName;

    @PrePersist
    public void onPrePersist(){
        Registerd registerd = new Registerd();
        BeanUtils.copyProperties(this, registerd);
        registerd.publishAfterCommit();

        //Following code causes dependency to external APIs
        // it is NOT A GOOD PRACTICE. instead, Event-Policy mapping is recommended.

        maskShop.external.Inventory inventory = new maskShop.external.Inventory();
        // mappings goes here
        ProductApplication.applicationContext.getBean(maskShop.external.InventoryService.class)
            .register(inventory);


    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }
    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }




}
